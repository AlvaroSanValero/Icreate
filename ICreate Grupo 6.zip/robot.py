from pycreate2 import Create2
import time
import math

class Robot:
    # Inicialización de la clase Robot con parámetros para puerto, velocidad, radio de la rueda, reducción, resolución del encoder y distancia entre ruedas
    def __init__(self, port="/dev/ttyUSB0", speed=200, wheel_radius=36, reduction=508.8, encoder_res=1, between_wheels_dist=235):
        Robot.initPos = (0, 0)  # Posición inicial del robot
        Robot.initOrientation = 0.  # Orientación inicial del robot
        Robot.errorThres = 2  # Umbral de error permitido
        Robot.correctionFactor = 2  # Factor de corrección para ajustar la velocidad
        Robot.errorRotate90 = 0.002  # Error de rotación para giros de 90 grados

        # Iniciar robot en modo `Safe`
        self.robot = Create2(port)  # Crear una instancia de Create2
        self.robot.start()  # Iniciar la comunicación con el robot
        self.robot.safe()  # Poner el robot en modo seguro

        self.speed = speed  # Velocidad del robot

        # Posición y orientación del robot (valores esperados, no los reales)
        self.x, self.y = Robot.initPos  # Inicializar la posición del robot
        self.theta = Robot.initOrientation  # Inicializar la orientación del robot

        # Distancias a obstáculos en la parte delantera izquierda, frontal y derecha
        self.distance_sensors = [10, 10, 10]  # Inicializar los sensores de distancia
        # Obtener valores iniciales de los encoders
        self.encoder_values = (self.robot.get_sensors().encoder_counts_left, self.robot.get_sensors().encoder_counts_right)
        print(self.encoder_values)
        # Factor de conversión para convertir los valores de los encoders a distancia real
        self.conversion_factor = 2 * math.pi * wheel_radius / (reduction * encoder_res)
        print(self.conversion_factor)
        self.between_wheels_dist = between_wheels_dist  # Distancia entre las ruedas del robot

    # Método para registrar errores en un archivo de texto
    def log_error(self, message):
        with open("log_error.txt", 'a') as file:
            file.write(message + '\n')

    # Método para registrar resultados en un archivo de texto
    def log_result(self, message):
        with open("log_result.txt", 'a') as file:
            file.write(message + '\n')

    # Método para actualizar los valores de los sensores del robot
    def __update_all_sensors(self):
        sensors = self.robot.get_sensors()  # Obtener todos los sensores del robot
        self.encoder_values = (sensors.encoder_counts_left, sensors.encoder_counts_right)  # Actualizar los valores de los encoders

    # Método recursivo para mover el robot una distancia específica con corrección de errores
    def rec_move(self, distance, speed, corrections):
        self.log_result(f"Iteración de movimiento n. {corrections}\nDistancia: {distance}\nVelocidad: {speed}")
        current_distance = 0  # Inicializar la distancia recorrida
        self.robot.drive_direct(speed, speed)  # Comenzar a mover el robot a la velocidad especificada
        while abs(current_distance) <= distance:  # Mientras no se haya recorrido la distancia objetivo
            prev_encoder = self.encoder_values  # Guardar los valores anteriores de los encoders
            print(prev_encoder)
            self.__update_all_sensors()  # Actualizar los valores de los encoders
            # Calcular la diferencia en los valores de los encoders
            encoder_dif = (self.encoder_values[0] - prev_encoder[0], self.encoder_values[1] - prev_encoder[1])
            # Convertir la diferencia de los encoders a distancia real y actualizar la distancia recorrida
            current_distance += self.conversion_factor * encoder_dif[0]

        self.robot.drive_stop()  # Detener el robot

        error = abs(current_distance) - distance  # Calcular el error en la distancia recorrida
        self.log_error(f"El error de movimiento es: {error}")
        # Si el error es mayor que el umbral y hay menos de 20 correcciones y la velocidad es suficiente para corregir
        if error > Robot.errorThres and corrections - 1 < 20 and abs(speed) // Robot.correctionFactor > 20:
            # Llamar recursivamente a rec_move para corregir el error
            self.rec_move(error, int((-1 if speed > 0 else 1) * (abs(speed) // Robot.correctionFactor)), corrections + 1)

    # Método para mover el robot una distancia específica
    def move(self, distance):
        self.rec_move(distance * (-1 if distance < 0 else 1), self.speed * (-1 if distance < 0 else 1) // 2, 0)
        # Actualizar la posición del robot en el plano 2D
        self.x += distance * math.cos(self.theta)
        self.y += distance * math.sin(self.theta)
        self.log_result(f"Resultados del movimiento: {self.x, self.y, self.theta}")

    # Método para rotar el robot un ángulo específico
    def rotate(self, angle):
        speedRotation = int(self.speed) // 4  # Calcular la velocidad de rotación
        # Calcular el error de rotación basado en el ángulo
        if abs(angle) >= 90:
            errorRotation = abs(angle) * self.errorRotate90 / 90
        else:
            errorRotation = self.errorRotate90
        print(errorRotation)
        counter = 0  # Contador para ajustar la velocidad
        speedLim = 20  # Límite mínimo de velocidad
        counterLim = 25  # Incremento para reducir la velocidad
        current_rotation = 0  # Inicializar la rotación actual
        angle = angle * math.pi / 180.  # Convertir el ángulo a radianes
        flag = True  # Indicador para el sentido de rotación
        error = angle  # Inicializar el error con el ángulo objetivo
        # Comenzar a rotar el robot en sentido horario
        self.robot.drive_direct(speedRotation, -speedRotation)
        
        while abs(error) >= errorRotation:  # Mientras el error sea mayor que el umbral de error
            # Si el robot necesita girar en sentido antihorario
            if error > 0 and not flag:
                counter += 1
                flag = True
                self.robot.drive_stop()
                self.robot.drive_direct(speedRotation, -speedRotation)
                if speedRotation > speedLim + counterLim:
                    speedRotation = speedRotation - counterLim
                else:
                    speedRotation = speedLim
                    time.sleep(0.2)

            # Si el robot necesita girar en sentido horario
            elif error < 0 and flag:
                counter += 1
                flag = False
                self.robot.drive_stop()
                self.robot.drive_direct(-speedRotation, speedRotation)
                if speedRotation > speedLim + counterLim:
                    speedRotation = speedRotation - counterLim
                else:
                    speedRotation = speedLim
                    time.sleep(0.2)

            prev_encoder = self.encoder_values  # Guardar los valores anteriores de los encoders
            self.__update_all_sensors()  # Actualizar los valores de los encoders
            # Calcular la diferencia en los valores de los encoders
            encoder_dif = (self.encoder_values[0] - prev_encoder[0], self.encoder_values[1] - prev_encoder[1])
            # Calcular la rotación actual del robot
            current_rotation -= 2 * encoder_dif[0] * self.conversion_factor / self.between_wheels_dist
                
            error = angle - current_rotation  # Calcular el error de rotación

        self.theta += (angle + error)  # Actualizar la orientación del robot
        self.log_result(f"Resultados del giro: {self.x, self.y, self.theta}")
        self.robot.drive_stop()  # Detener el robot

    # Método para actualizar manualmente los valores de los sensores de distancia
    def update_distance_sensors(self, distances):
        self.distance_sensors = distances  # Actualizar los sensores de distancia

class OdometryCalculator:
    def __init__(self, robot):
        self.robot = robot

# Ejemplo de uso
robot = Robot()  # Crear una instancia de Robot
odometry_calculator = OdometryCalculator(robot)  # Crear una instancia de OdometryCalculator

log_error = "log_error.txt"
log_result = "log_result.txt"

# Movimiento del robot y actualización de las distancias de los sensores
robot.move(100)  # Mover el robot 100 mm hacia adelante
time.sleep(1)  # Esperar 1 segundo
robot.rotate(90)  # Rotar el robot 90 grados hacia la derecha
time.sleep(1)

robot.move(100)  # Mover el robot 100 mm hacia adelante
time.sleep(1)
robot.rotate(90)  # Rotar el robot 90 grados hacia la derecha
time.sleep(1)

robot.move(100)  # Mover el robot 100 mm hacia adelante
time.sleep(1)
robot.rotate(90)  # Rotar el robot 90 grados hacia la derecha
time.sleep(1)

robot.move(100)  # Mover el robot 100 mm hacia adelante
time.sleep(1)
robot.rotate(90)  # Rotar el robot 90 grados hacia la derecha
time.sleep(1)

